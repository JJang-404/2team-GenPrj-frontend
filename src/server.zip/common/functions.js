import { BACKEND_BASE_URL } from './defines';

export function getBackendUrl() {
  // In Vite dev, use relative path so requests go through dev-server proxy (/addhelper -> target).
  if (import.meta.env.DEV) {
    return '/addhelper';
  }

  // In production, allow env override and fallback to constant.
  return import.meta.env.VITE_BACKEND_BASE_URL || BACKEND_BASE_URL;
}

